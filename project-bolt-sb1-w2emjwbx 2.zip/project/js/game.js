/**
 * Main game logic
 */
const Game = {
  board: null,
  score: 0,
  moves: CONFIG.STARTING_MOVES,
  objective: { ...CONFIG.DEFAULT_OBJECTIVE },
  objectiveProgress: 0,
  isGameOver: false,
  
  /**
   * Initialize the game
   */
  init() {
    // Initialize the sound manager
    SoundManager.init();
    
    // Initialize UI
    UI.init();
    
    // Create the game board
    this.board = new GameBoard(CONFIG.COLUMNS, CONFIG.ROWS);
  },
  
  /**
   * Start a new game
   */
  start() {
    this.isGameOver = false;
    this.score = 0;
    this.moves = CONFIG.STARTING_MOVES;
    this.objective = { ...CONFIG.DEFAULT_OBJECTIVE };
    this.objectiveProgress = 0;
    
    UI.updateScoreDisplay(this.score);
    UI.updateMovesDisplay(this.moves);
    UI.updateObjectiveDisplay(this.objective);
    UI.updateProgressBar(0, this.objective.count);
    
    // Initialize the board
    this.board.init();
    
    // Show welcome comment from Taffy
    this.taffyComment('welcome');
  },
  
  /**
   * Reset the game
   */
  reset() {
    this.start();
  },
  
  /**
   * Make Taffy comment on a game situation
   * @param {string} situation - The game situation
   * @param {number} matchSize - The size of the match (optional)
   */
  taffyComment(situation, matchSize = 0) {
    Taffy.comment(situation, matchSize);
  },
  
  /**
   * Increase the score
   * @param {number} points - Points to add
   */
  increaseScore(points) {
    this.score += points;
    UI.updateScoreDisplay(this.score);
  },
  
  /**
   * Decrement the number of moves
   */
  decrementMoves() {
    this.moves--;
    UI.updateMovesDisplay(this.moves);
    
    // Check if moves are low
    if (this.moves === 5) {
      this.taffyComment('low-moves');
    }
    
    // Check for game over
    if (this.moves <= 0) {
      this.checkGameConditions();
    }
  },
  
  /**
   * Update the objective progress based on matched candies
   * @param {Array} matches - Array of matched candies
   */
  updateObjectiveProgress(matches) {
    if (this.objective.type === CONFIG.OBJECTIVE_TYPES.MATCH_SPECIFIC) {
      // Count matches of the target type
      let matchCount = 0;
      matches.forEach(candy => {
        if (candy.type === this.objective.candyType) {
          matchCount++;
        }
      });
      
      // Update progress
      this.objectiveProgress += matchCount;
      UI.updateProgressBar(this.objectiveProgress, this.objective.count);
    } else if (this.objective.type === CONFIG.OBJECTIVE_TYPES.SCORE_TARGET) {
      // Progress is based on score percentage
      const percentage = Math.min(this.score / this.objective.score, 1);
      UI.updateProgressBar(Math.floor(percentage * 100), 100);
    }
  },
  
  /**
   * Check if game conditions (win/lose) are met
   */
  checkGameConditions() {
    if (this.isGameOver) return;
    
    // Win condition: objective completed
    if ((this.objective.type === CONFIG.OBJECTIVE_TYPES.MATCH_SPECIFIC && 
        this.objectiveProgress >= this.objective.count) ||
        (this.objective.type === CONFIG.OBJECTIVE_TYPES.SCORE_TARGET &&
        this.score >= this.objective.score)) {
      
      this.taffyComment('objective-complete');
      this.isGameOver = true;
      
      // Small delay before showing win screen
      setTimeout(() => {
        UI.showWinScreen(this.score, this.moves);
      }, 1500);
      
      return;
    }
    
    // Lose condition: out of moves
    if (this.moves <= 0) {
      this.taffyComment('game-over');
      this.isGameOver = true;
      
      // Small delay before showing lose screen
      setTimeout(() => {
        UI.showLoseScreen(
          this.score,
          this.objective.type === CONFIG.OBJECTIVE_TYPES.MATCH_SPECIFIC
            ? `${this.objectiveProgress}/${this.objective.count}`
            : `${Math.floor((this.score / this.objective.score) * 100)}%`
        );
      }, 1500);
      
      return;
    }
    
    // Check if there are any possible moves
    if (!this.board.hasPossibleMoves()) {
      // No moves available, reshuffle the board
      this.taffyComment('no-moves');
      
      // Reset the board
      this.board.reset();
    }
  }
};