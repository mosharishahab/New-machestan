/**
 * Sound management for the game
 */
const SoundManager = {
  // Sound effects
  sounds: {
    match: new Audio('https://assets.mixkit.co/active_storage/sfx/2005/2005-preview.mp3'),
    swap: new Audio('https://assets.mixkit.co/active_storage/sfx/270/270-preview.mp3'),
    noMatch: new Audio('https://assets.mixkit.co/active_storage/sfx/2009/2009-preview.mp3'),
    win: new Audio('https://assets.mixkit.co/active_storage/sfx/2013/2013-preview.mp3'),
    lose: new Audio('https://assets.mixkit.co/active_storage/sfx/2019/2019-preview.mp3')
  },
  
  /**
   * Initialize sound settings
   */
  init() {
    // Set volumes
    this.sounds.match.volume = CONFIG.MATCH_SOUND_VOLUME;
    this.sounds.swap.volume = CONFIG.SWAP_SOUND_VOLUME;
    this.sounds.noMatch.volume = 0.2;
    this.sounds.win.volume = 0.4;
    this.sounds.lose.volume = 0.4;
    
    // Preload sounds
    for (const sound in this.sounds) {
      this.sounds[sound].load();
    }
  },
  
  /**
   * Play a sound effect
   * @param {string} soundName - The name of the sound to play
   */
  play(soundName) {
    if (this.sounds[soundName]) {
      // Reset the audio to the beginning if it's already playing
      this.sounds[soundName].currentTime = 0;
      this.sounds[soundName].play().catch(e => {
        console.warn('Sound play prevented:', e);
      });
    }
  }
};