/**
 * Taffy character management
 */
const Taffy = {
  // Taffy's phrases for different situations
  phrases: {
    'welcome': [
      "Welcome to Mochestan, friend! Let's match some candies!",
      "Salaam! Ready to create some sweet magic?",
      "The Persian candy market is open! Let's start matching!"
    ],
    'candy-selected': [
      "Oh, that's a tasty looking treat!",
      "Nice choice! Where will you move it?",
      "That candy looks delicious, meow!",
      "Hmm, strategic selection!"
    ],
    'candy-deselected': [
      "Changed your mind? That's purr-fectly fine!",
      "Let's try another candy instead!",
      "Take your time, there's no rush!"
    ],
    'match-made': [
      "Sweet match! You're getting good at this!",
      "Excellent! The candies go poof!",
      "What a delightful combination!",
      "That's how we do it in Mochestan!"
    ],
    'match-made-large': [
      "Incredible match! You're a candy master!",
      "By my whiskers, what a magnificent match!",
      "Outstanding! The market has never seen such skill!"
    ],
    'no-match': [
      "That didn't work. Try another move!",
      "Those candies don't want to swap. Try again!",
      "Not a match, but keep trying!"
    ],
    'cascade': [
      "It's raining candies! What a cascade!",
      "One match leads to another! Brilliant!",
      "The candies are falling into place!"
    ],
    'low-moves': [
      "Only a few moves left! Make them count!",
      "Better be careful now, moves are running low!",
      "Time to get strategic, moves are precious now!"
    ],
    'objective-complete': [
      "You did it! Objective complete!",
      "Mission accomplished! You're amazing!",
      "Sweet victory! The market celebrates your skill!"
    ],
    'game-over': [
      "Game over! But the market always reopens tomorrow!",
      "Oh no! We ran out of moves this time!",
      "Better luck next time, my friend!"
    ],
    'invalid-move': [
      "Oops! That's not a valid move!",
      "The candies can only move to adjacent spots!",
      "Try swiping to an adjacent candy!"
    ]
  },
  
  /**
   * Get a random phrase for a specific situation
   * @param {string} situation - The game situation
   * @returns {string} A random phrase for the situation
   */
  getPhrase(situation) {
    if (this.phrases[situation]) {
      return Utils.getRandomElement(this.phrases[situation]);
    }
    return "Meow! Keep matching those candies!";
  },
  
  /**
   * Display a comment from Taffy
   * @param {string} situation - The game situation
   * @param {number} matchSize - The size of the match (optional)
   */
  comment(situation, matchSize = 0) {
    let phrase;
    
    // Special case for large matches
    if (situation === 'match-made' && matchSize > 4) {
      phrase = this.getPhrase('match-made-large');
    } else {
      phrase = this.getPhrase(situation);
    }
    
    Animations.showTaffySpeech(phrase);
  }
};