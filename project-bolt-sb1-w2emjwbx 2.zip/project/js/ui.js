/**
 * UI management for the game
 */
const UI = {
  // Screen elements
  screens: {
    welcome: document.getElementById('welcome-screen'),
    game: document.getElementById('game-screen'),
    win: document.getElementById('win-screen'),
    lose: document.getElementById('lose-screen')
  },
  
  // UI elements
  elements: {
    scoreDisplay: document.getElementById('score'),
    movesDisplay: document.getElementById('moves'),
    objectiveDisplay: document.getElementById('objective'),
    progressFill: document.getElementById('progress-fill'),
    progressText: document.getElementById('progress-text'),
    finalScoreWin: document.getElementById('final-score-win'),
    finalScoreLose: document.getElementById('final-score-lose'),
    movesLeft: document.getElementById('moves-left'),
    finalProgress: document.getElementById('final-progress'),
    startButton: document.getElementById('start-button'),
    playAgainWinButton: document.getElementById('play-again-win'),
    playAgainLoseButton: document.getElementById('play-again-lose')
  },
  
  /**
   * Initialize the UI
   */
  init() {
    this.attachEventListeners();
    this.updateScoreDisplay(0);
    this.updateMovesDisplay(CONFIG.STARTING_MOVES);
    this.updateObjectiveDisplay(CONFIG.DEFAULT_OBJECTIVE);
    
    // Set the document title
    document.title = 'Mochestan - Persian Candy Match Game';
  },
  
  /**
   * Attach event listeners to UI elements
   */
  attachEventListeners() {
    // Start button
    this.elements.startButton.addEventListener('click', () => {
      this.showScreen('game');
      Game.start();
    });
    
    // Play again buttons
    this.elements.playAgainWinButton.addEventListener('click', () => {
      this.showScreen('game');
      Game.reset();
    });
    
    this.elements.playAgainLoseButton.addEventListener('click', () => {
      this.showScreen('game');
      Game.reset();
    });
  },
  
  /**
   * Show a specific screen and hide others
   * @param {string} screenName - The name of the screen to show
   */
  showScreen(screenName) {
    // Hide all screens
    Object.values(this.screens).forEach(screen => {
      screen.classList.remove('active');
    });
    
    // Show the requested screen
    if (this.screens[screenName]) {
      this.screens[screenName].classList.add('active');
    }
  },
  
  /**
   * Update the score display
   * @param {number} score - The current score
   */
  updateScoreDisplay(score) {
    this.elements.scoreDisplay.textContent = Utils.formatNumber(score);
  },
  
  /**
   * Update the moves display
   * @param {number} moves - The current moves
   */
  updateMovesDisplay(moves) {
    this.elements.movesDisplay.textContent = moves;
    
    // Highlight low moves
    if (moves <= 5) {
      this.elements.movesDisplay.classList.add('low-moves');
    } else {
      this.elements.movesDisplay.classList.remove('low-moves');
    }
  },
  
  /**
   * Update the objective display
   * @param {Object} objective - The current objective
   */
  updateObjectiveDisplay(objective) {
    let objectiveText = '';
    
    if (objective.type === CONFIG.OBJECTIVE_TYPES.MATCH_SPECIFIC) {
      objectiveText = `Match ${objective.count} ${objective.candyType}s`;
      
      // Update the objective icon
      const objectiveIcon = document.querySelector('.objective-icon');
      if (objectiveIcon) {
        objectiveIcon.className = `objective-icon ${objective.candyType}`;
      }
    } else if (objective.type === CONFIG.OBJECTIVE_TYPES.SCORE_TARGET) {
      objectiveText = `Score ${Utils.formatNumber(objective.score)} points`;
    }
    
    this.elements.objectiveDisplay.textContent = objectiveText;
  },
  
  /**
   * Update the progress bar
   * @param {number} current - Current progress
   * @param {number} target - Target value
   */
  updateProgressBar(current, target) {
    const percentage = Math.min(100, (current / target) * 100);
    this.elements.progressFill.style.width = `${percentage}%`;
    this.elements.progressText.textContent = `${current}/${target}`;
  },
  
  /**
   * Show win screen with game statistics
   * @param {number} score - Final score
   * @param {number} movesLeft - Remaining moves
   */
  showWinScreen(score, movesLeft) {
    this.elements.finalScoreWin.textContent = Utils.formatNumber(score);
    this.elements.movesLeft.textContent = movesLeft;
    this.showScreen('win');
    SoundManager.play('win');
  },
  
  /**
   * Show lose screen with game statistics
   * @param {number} score - Final score
   * @param {string} progress - Objective progress text
   */
  showLoseScreen(score, progress) {
    this.elements.finalScoreLose.textContent = Utils.formatNumber(score);
    this.elements.finalProgress.textContent = progress;
    this.showScreen('lose');
    SoundManager.play('lose');
  }
};