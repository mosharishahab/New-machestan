/**
 * Game configuration parameters
 */
const CONFIG = {
  // Board dimensions
  COLUMNS: 8,
  ROWS: 10,
  
  // Candy types
  CANDY_TYPES: ['heart', 'circle', 'triangle', 'square'],
  
  // Game settings
  STARTING_MOVES: 30,
  MATCH_SOUND_VOLUME: 0.3,
  SWAP_SOUND_VOLUME: 0.2,
  
  // Animation durations (ms)
  SWAP_ANIMATION_DURATION: 300,
  POP_ANIMATION_DURATION: 500,
  DROP_ANIMATION_DURATION: 500,
  
  // Scoring
  MATCH_BASE_SCORE: 10,
  MATCH_BONUS_PER_EXTRA: 5,  // Additional points per extra matched candy beyond 3
  
  // Objectives
  OBJECTIVE_TYPES: {
    MATCH_SPECIFIC: 'match_specific',
    SCORE_TARGET: 'score_target'
  },
  
  // Default objective
  DEFAULT_OBJECTIVE: {
    type: 'match_specific',
    candyType: 'heart',
    count: 10
  }
};