/**
 * Utility functions for the game
 */
const Utils = {
  /**
   * Generate a random integer between min and max (inclusive)
   * @param {number} min - The minimum value
   * @param {number} max - The maximum value
   * @returns {number} A random integer
   */
  getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },
  
  /**
   * Shuffle an array using the Fisher-Yates algorithm
   * @param {Array} array - The array to shuffle
   * @returns {Array} The shuffled array
   */
  shuffleArray(array) {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
  },
  
  /**
   * Delay execution for a specified amount of time
   * @param {number} ms - Milliseconds to delay
   * @returns {Promise} A promise that resolves after the delay
   */
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  },
  
  /**
   * Check if two positions are adjacent
   * @param {Object} pos1 - First position {row, col}
   * @param {Object} pos2 - Second position {row, col}
   * @returns {boolean} True if positions are adjacent
   */
  areAdjacent(pos1, pos2) {
    const rowDiff = Math.abs(pos1.row - pos2.row);
    const colDiff = Math.abs(pos1.col - pos2.col);
    
    return (rowDiff === 1 && colDiff === 0) || (rowDiff === 0 && colDiff === 1);
  },
  
  /**
   * Format a number with commas as thousands separators
   * @param {number} num - The number to format
   * @returns {string} The formatted number
   */
  formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  },
  
  /**
   * Get a random element from an array
   * @param {Array} array - The array to choose from
   * @returns {*} A random element from the array
   */
  getRandomElement(array) {
    return array[Math.floor(Math.random() * array.length)];
  }
};