/**
 * Game board management
 */
class GameBoard {
  /**
   * Create a new game board
   * @param {number} columns - Number of columns in the board
   * @param {number} rows - Number of rows in the board
   */
  constructor(columns, rows) {
    this.columns = columns;
    this.rows = rows;
    this.candies = [];
    this.boardElement = document.getElementById('game-board');
    this.selectedCandy = null;
    this.isSwapping = false;
    this.isProcessingMatches = false;
  }
  
  /**
   * Initialize the game board
   */
  init() {
    this.createBoard();
    this.fillBoard();
    this.renderBoard();
    this.attachEventListeners();
  }
  
  /**
   * Create the board grid
   */
  createBoard() {
    // Clear the board element
    this.boardElement.innerHTML = '';
    
    // Create the cells
    for (let row = 0; row < this.rows; row++) {
      for (let col = 0; col < this.columns; col++) {
        const cell = document.createElement('div');
        cell.className = 'candy-cell';
        cell.dataset.row = row;
        cell.dataset.col = col;
        this.boardElement.appendChild(cell);
      }
    }
  }
  
  /**
   * Fill the board with random candies
   */
  fillBoard() {
    // Initialize empty board
    this.candies = Array(this.rows).fill().map(() => Array(this.columns).fill(null));
    
    // Fill the board with random candies
    for (let row = 0; row < this.rows; row++) {
      for (let col = 0; col < this.columns; col++) {
        const type = this.getRandomCandyType();
        this.candies[row][col] = new Candy(type, row, col);
      }
    }
    
    // Ensure no matches exist at the start of the game
    this.resolveInitialMatches();
  }
  
  /**
   * Get a random candy type, avoiding making initial matches
   * @param {number} row - Current row
   * @param {number} col - Current column
   * @returns {string} A random candy type
   */
  getRandomCandyType(row, col) {
    // If not checking for matches, just return a random type
    if (row === undefined || col === undefined) {
      return Utils.getRandomElement(CONFIG.CANDY_TYPES);
    }
    
    // Get all possible candy types
    const allTypes = [...CONFIG.CANDY_TYPES];
    
    // Shuffle them for randomness
    const shuffledTypes = Utils.shuffleArray(allTypes);
    
    // Try each type to find one that doesn't create a match
    for (const type of shuffledTypes) {
      if (!this.wouldCreateMatch(row, col, type)) {
        return type;
      }
    }
    
    // If all types would create a match, just pick a random one
    return Utils.getRandomElement(CONFIG.CANDY_TYPES);
  }
  
  /**
   * Check if placing a candy type at position would create a match
   * @param {number} row - The row position
   * @param {number} col - The column position
   * @param {string} type - The candy type to check
   * @returns {boolean} True if it would create a match
   */
  wouldCreateMatch(row, col, type) {
    // Check horizontally
    let matchCount = 1;
    
    // Check left
    for (let i = col - 1; i >= 0 && i >= col - 2; i--) {
      if (this.candies[row] && this.candies[row][i] && this.candies[row][i].type === type) {
        matchCount++;
      } else {
        break;
      }
    }
    
    // Check right
    for (let i = col + 1; i < this.columns && i <= col + 2; i++) {
      if (this.candies[row] && this.candies[row][i] && this.candies[row][i].type === type) {
        matchCount++;
      } else {
        break;
      }
    }
    
    if (matchCount >= 3) return true;
    
    // Check vertically
    matchCount = 1;
    
    // Check up
    for (let i = row - 1; i >= 0 && i >= row - 2; i--) {
      if (this.candies[i] && this.candies[i][col] && this.candies[i][col].type === type) {
        matchCount++;
      } else {
        break;
      }
    }
    
    // Check down
    for (let i = row + 1; i < this.rows && i <= row + 2; i++) {
      if (this.candies[i] && this.candies[i][col] && this.candies[i][col].type === type) {
        matchCount++;
      } else {
        break;
      }
    }
    
    return matchCount >= 3;
  }
  
  /**
   * Resolve any initial matches on the board
   */
  resolveInitialMatches() {
    let hasMatches = true;
    
    while (hasMatches) {
      hasMatches = false;
      
      for (let row = 0; row < this.rows; row++) {
        for (let col = 0; col < this.columns; col++) {
          // Check horizontal matches
          if (col > 1 &&
              this.candies[row][col].type === this.candies[row][col-1].type &&
              this.candies[row][col].type === this.candies[row][col-2].type) {
            // Replace the current candy with a different type
            const newType = this.getNewCandyType(this.candies[row][col].type);
            this.candies[row][col] = new Candy(newType, row, col);
            hasMatches = true;
          }
          
          // Check vertical matches
          if (row > 1 &&
              this.candies[row][col].type === this.candies[row-1][col].type &&
              this.candies[row][col].type === this.candies[row-2][col].type) {
            // Replace the current candy with a different type
            const newType = this.getNewCandyType(this.candies[row][col].type);
            this.candies[row][col] = new Candy(newType, row, col);
            hasMatches = true;
          }
        }
      }
    }
  }
  
  /**
   * Get a new candy type that is different from the current type
   * @param {string} currentType - The current candy type to avoid
   * @returns {string} A different candy type
   */
  getNewCandyType(currentType) {
    const availableTypes = CONFIG.CANDY_TYPES.filter(type => type !== currentType);
    return Utils.getRandomElement(availableTypes);
  }
  
  /**
   * Render the board and candies
   */
  renderBoard() {
    // Clear existing candies from cells
    const cells = document.querySelectorAll('.candy-cell');
    cells.forEach(cell => {
      cell.innerHTML = '';
    });
    
    // Render each candy
    for (let row = 0; row < this.rows; row++) {
      for (let col = 0; col < this.columns; col++) {
        const candy = this.candies[row][col];
        if (candy) {
          const element = candy.createElement();
          const cell = document.querySelector(`.candy-cell[data-row="${row}"][data-col="${col}"]`);
          if (cell) {
            cell.appendChild(element);
          }
        }
      }
    }
  }
  
  /**
   * Attach event listeners to the board
   */
  attachEventListeners() {
    this.boardElement.addEventListener('click', this.handleCandyClick.bind(this));
    this.boardElement.addEventListener('touchstart', this.handleTouchStart.bind(this), { passive: true });
    this.boardElement.addEventListener('touchmove', this.handleTouchMove.bind(this), { passive: false });
    this.boardElement.addEventListener('touchend', this.handleTouchEnd.bind(this), { passive: true });
  }
  
  /**
   * Handle candy click events
   * @param {Event} event - The click event
   */
  handleCandyClick(event) {
    if (this.isSwapping || this.isProcessingMatches) return;
    
    const element = event.target.closest('.candy');
    if (!element) return;
    
    const row = parseInt(element.dataset.row);
    const col = parseInt(element.dataset.col);
    const candy = this.candies[row][col];
    
    if (!candy) return;
    
    // If no candy is selected, select this one
    if (!this.selectedCandy) {
      this.selectedCandy = candy;
      candy.select();
      
      // Show Taffy comment
      Game.taffyComment('candy-selected');
    } 
    // If a candy is already selected
    else {
      // If this is the same candy, deselect it
      if (this.selectedCandy === candy) {
        this.selectedCandy.deselect();
        this.selectedCandy = null;
        
        // Show Taffy comment
        Game.taffyComment('candy-deselected');
      } 
      // If it's a different candy, check if they are adjacent
      else if (Utils.areAdjacent(
        { row: this.selectedCandy.row, col: this.selectedCandy.col },
        { row: candy.row, col: candy.col }
      )) {
        // Try to swap the candies
        this.swapCandies(this.selectedCandy, candy);
      } 
      // If they're not adjacent, deselect the first and select this one
      else {
        this.selectedCandy.deselect();
        this.selectedCandy = candy;
        candy.select();
        
        // Show Taffy comment
        Game.taffyComment('candy-selected');
      }
    }
  }
  
  // Touch event variables
  touchStartX = 0;
  touchStartY = 0;
  touchStartRow = -1;
  touchStartCol = -1;
  touchThreshold = 30; // Minimum distance to trigger a swipe
  
  /**
   * Handle touch start event for drag-and-drop on mobile
   * @param {TouchEvent} event - The touch event
   */
  handleTouchStart(event) {
    if (this.isSwapping || this.isProcessingMatches) return;
    
    const touch = event.touches[0];
    const element = document.elementFromPoint(touch.clientX, touch.clientY);
    const candyElement = element?.closest('.candy');
    
    if (candyElement) {
      const row = parseInt(candyElement.dataset.row);
      const col = parseInt(candyElement.dataset.col);
      
      this.touchStartX = touch.clientX;
      this.touchStartY = touch.clientY;
      this.touchStartRow = row;
      this.touchStartCol = col;
      
      const candy = this.candies[row][col];
      if (candy) {
        candy.select();
        // Show Taffy comment
        Game.taffyComment('candy-selected');
      }
    }
  }
  
  /**
   * Handle touch move event for drag-and-drop on mobile
   * @param {TouchEvent} event - The touch event
   */
  handleTouchMove(event) {
    // Prevent scrolling while dragging candies
    if (this.touchStartRow !== -1 && this.touchStartCol !== -1) {
      event.preventDefault();
    }
  }
  
  /**
   * Handle touch end event for drag-and-drop on mobile
   * @param {TouchEvent} event - The touch event
   */
  handleTouchEnd(event) {
    if (this.isSwapping || this.isProcessingMatches || this.touchStartRow === -1 || this.touchStartCol === -1) {
      // Reset touch state
      this.touchStartRow = -1;
      this.touchStartCol = -1;
      return;
    }
    
    const touch = event.changedTouches[0];
    const deltaX = touch.clientX - this.touchStartX;
    const deltaY = touch.clientY - this.touchStartY;
    
    // Deselect the starting candy
    const startCandy = this.candies[this.touchStartRow][this.touchStartCol];
    if (startCandy) {
      startCandy.deselect();
    }
    
    // Check if the swipe was significant enough
    if (Math.abs(deltaX) < this.touchThreshold && Math.abs(deltaY) < this.touchThreshold) {
      // Show deselect comment if it was a tap
      Game.taffyComment('candy-deselected');
      
      // Reset touch state
      this.touchStartRow = -1;
      this.touchStartCol = -1;
      return;
    }
    
    // Determine the direction of the swipe
    let targetRow = this.touchStartRow;
    let targetCol = this.touchStartCol;
    
    if (Math.abs(deltaX) > Math.abs(deltaY)) {
      // Horizontal swipe
      targetCol += (deltaX > 0) ? 1 : -1;
    } else {
      // Vertical swipe
      targetRow += (deltaY > 0) ? 1 : -1;
    }
    
    // Check if the target position is valid
    if (targetRow >= 0 && targetRow < this.rows && targetCol >= 0 && targetCol < this.columns) {
      const targetCandy = this.candies[targetRow][targetCol];
      
      if (targetCandy && startCandy) {
        // Swap the candies
        this.swapCandies(startCandy, targetCandy);
      }
    } else {
      // Show invalid move comment
      Game.taffyComment('invalid-move');
    }
    
    // Reset touch state
    this.touchStartRow = -1;
    this.touchStartCol = -1;
  }
  
  /**
   * Swap two candies and check for matches
   * @param {Candy} candy1 - First candy to swap
   * @param {Candy} candy2 - Second candy to swap
   */
  async swapCandies(candy1, candy2) {
    if (this.isSwapping || this.isProcessingMatches) return;
    
    this.isSwapping = true;
    
    // Deselect the first candy if it was selected
    if (this.selectedCandy) {
      this.selectedCandy.deselect();
      this.selectedCandy = null;
    }
    
    // Swap candy positions in the array
    [
      this.candies[candy1.row][candy1.col],
      this.candies[candy2.row][candy2.col]
    ] = [
      this.candies[candy2.row][candy2.col],
      this.candies[candy1.row][candy1.col]
    ];
    
    // Update the candies' row and col properties
    [candy1.row, candy1.col, candy2.row, candy2.col] = [candy2.row, candy2.col, candy1.row, candy1.col];
    
    // Play swap sound
    SoundManager.play('swap');
    
    // Animate the swap
    await Animations.swapCandies(candy1, candy2);
    
    // Update the DOM elements' positions
    candy1.updatePosition();
    candy2.updatePosition();
    
    // Check for matches
    const matches = this.findMatches();
    
    // If no matches were made, swap back
    if (matches.length === 0) {
      // Play no match sound
      SoundManager.play('noMatch');
      
      // Show no match comment
      Game.taffyComment('no-match');
      
      // Swap back in the array
      [
        this.candies[candy1.row][candy1.col],
        this.candies[candy2.row][candy2.col]
      ] = [
        this.candies[candy2.row][candy2.col],
        this.candies[candy1.row][candy1.col]
      ];
      
      // Update candies' row and col properties
      [candy1.row, candy1.col, candy2.row, candy2.col] = [candy2.row, candy2.col, candy1.row, candy1.col];
      
      // Animate the swap back
      await Animations.swapCandies(candy1, candy2);
      
      // Update the DOM elements' positions
      candy1.updatePosition();
      candy2.updatePosition();
    } else {
      // Valid move, decrement moves
      Game.decrementMoves();
      
      // Process the matches
      await this.processMatches(matches);
    }
    
    this.isSwapping = false;
  }
  
  /**
   * Find all current matches on the board
   * @returns {Array} Array of matched candy groups
   */
  findMatches() {
    const allMatches = [];
    
    // Check horizontal matches
    for (let row = 0; row < this.rows; row++) {
      for (let col = 0; col < this.columns - 2; col++) {
        const candy1 = this.candies[row][col];
        const candy2 = this.candies[row][col + 1];
        const candy3 = this.candies[row][col + 2];
        
        if (candy1 && candy2 && candy3 &&
            candy1.type === candy2.type && candy2.type === candy3.type) {
          
          // Find the full extent of the match
          let matchEnd = col + 2;
          for (let k = col + 3; k < this.columns; k++) {
            if (this.candies[row][k] && this.candies[row][k].type === candy1.type) {
              matchEnd = k;
            } else {
              break;
            }
          }
          
          // Collect all candies in this match
          const matchedCandies = [];
          for (let k = col; k <= matchEnd; k++) {
            matchedCandies.push(this.candies[row][k]);
          }
          
          allMatches.push(matchedCandies);
          
          // Skip columns that are already part of this match
          col = matchEnd;
        }
      }
    }
    
    // Check vertical matches
    for (let col = 0; col < this.columns; col++) {
      for (let row = 0; row < this.rows - 2; row++) {
        const candy1 = this.candies[row][col];
        const candy2 = this.candies[row + 1][col];
        const candy3 = this.candies[row + 2][col];
        
        if (candy1 && candy2 && candy3 &&
            candy1.type === candy2.type && candy2.type === candy3.type) {
          
          // Find the full extent of the match
          let matchEnd = row + 2;
          for (let k = row + 3; k < this.rows; k++) {
            if (this.candies[k][col] && this.candies[k][col].type === candy1.type) {
              matchEnd = k;
            } else {
              break;
            }
          }
          
          // Collect all candies in this match
          const matchedCandies = [];
          for (let k = row; k <= matchEnd; k++) {
            matchedCandies.push(this.candies[k][col]);
          }
          
          allMatches.push(matchedCandies);
          
          // Skip rows that are already part of this match
          row = matchEnd;
        }
      }
    }
    
    // Remove duplicates (candies that are part of both horizontal and vertical matches)
    const uniqueCandies = new Set();
    allMatches.forEach(match => {
      match.forEach(candy => {
        uniqueCandies.add(candy);
      });
    });
    
    return Array.from(uniqueCandies);
  }
  
  /**
   * Process matches by removing matched candies and filling gaps
   * @param {Array} matches - Array of matched candies
   */
  async processMatches(matches) {
    if (this.isProcessingMatches) return;
    
    this.isProcessingMatches = true;
    
    // Play match sound
    SoundManager.play('match');
    
    // Show match comment
    Game.taffyComment('match-made', matches.length);
    
    // Calculate score for the matches
    const score = this.calculateScore(matches);
    Game.increaseScore(score);
    
    // Update objective if needed
    Game.updateObjectiveProgress(matches);
    
    // Animate the matched candies popping
    await Animations.popCandies(matches);
    
    // Remove matched candies from the board
    matches.forEach(candy => {
      this.candies[candy.row][candy.col] = null;
    });
    
    // Fill the gaps by moving candies down
    await this.fillGaps();
    
    // Check for cascading matches
    const cascadingMatches = this.findMatches();
    if (cascadingMatches.length > 0) {
      // Show cascade comment
      Game.taffyComment('cascade');
      
      // Process cascading matches
      await this.processMatches(cascadingMatches);
    }
    
    // Check if game conditions (win/lose) are met
    Game.checkGameConditions();
    
    this.isProcessingMatches = false;
  }
  
  /**
   * Calculate score based on matched candies
   * @param {Array} matches - Array of matched candies
   * @returns {number} Score for the matches
   */
  calculateScore(matches) {
    // Base score for any match is CONFIG.MATCH_BASE_SCORE
    // Add bonus points for matches larger than 3
    return CONFIG.MATCH_BASE_SCORE + Math.max(0, matches.length - 3) * CONFIG.MATCH_BONUS_PER_EXTRA;
  }
  
  /**
   * Fill gaps by moving candies down and adding new ones at the top
   */
  async fillGaps() {
    // Keep track of candies that need animation
    const droppingCandies = [];
    
    // For each column
    for (let col = 0; col < this.columns; col++) {
      // Count empty spaces
      let emptyCount = 0;
      
      // Process from bottom to top
      for (let row = this.rows - 1; row >= 0; row--) {
        // If this cell is empty, increment empty count
        if (this.candies[row][col] === null) {
          emptyCount++;
        } 
        // If there's a candy and empty spaces below, move it down
        else if (emptyCount > 0) {
          // Move the candy down by the number of empty spaces
          const candy = this.candies[row][col];
          this.candies[row + emptyCount][col] = candy;
          this.candies[row][col] = null;
          
          // Update the candy's position
          candy.row = row + emptyCount;
          candy.updatePosition();
          
          // Add to the list of dropping candies
          droppingCandies.push(candy);
        }
      }
      
      // Fill the top with new candies
      for (let i = 0; i < emptyCount; i++) {
        const row = emptyCount - i - 1;
        const type = this.getRandomCandyType();
        const newCandy = new Candy(type, row, col);
        this.candies[row][col] = newCandy;
        
        // Create DOM element for the new candy
        const element = newCandy.createElement();
        const cell = document.querySelector(`.candy-cell[data-row="${row}"][data-col="${col}"]`);
        if (cell) {
          cell.appendChild(element);
        }
        
        // Add to the list of dropping candies
        droppingCandies.push(newCandy);
      }
    }
    
    // Animate the candies dropping
    if (droppingCandies.length > 0) {
      await Animations.dropCandies(droppingCandies);
    }
  }
  
  /**
   * Check if there are any possible moves on the board
   * @returns {boolean} True if there are possible moves
   */
  hasPossibleMoves() {
    // Check each position on the board
    for (let row = 0; row < this.rows; row++) {
      for (let col = 0; col < this.columns; col++) {
        // Try swapping with adjacent positions and check for matches
        
        // Swap right
        if (col < this.columns - 1) {
          // Try the swap
          [this.candies[row][col], this.candies[row][col + 1]] = 
          [this.candies[row][col + 1], this.candies[row][col]];
          
          // Update positions
          if (this.candies[row][col]) this.candies[row][col].col = col;
          if (this.candies[row][col + 1]) this.candies[row][col + 1].col = col + 1;
          
          // Check for matches
          const matches = this.findMatches();
          
          // Swap back
          [this.candies[row][col], this.candies[row][col + 1]] = 
          [this.candies[row][col + 1], this.candies[row][col]];
          
          // Update positions back
          if (this.candies[row][col]) this.candies[row][col].col = col;
          if (this.candies[row][col + 1]) this.candies[row][col + 1].col = col + 1;
          
          if (matches.length > 0) {
            return true;
          }
        }
        
        // Swap down
        if (row < this.rows - 1) {
          // Try the swap
          [this.candies[row][col], this.candies[row + 1][col]] = 
          [this.candies[row + 1][col], this.candies[row][col]];
          
          // Update positions
          if (this.candies[row][col]) this.candies[row][col].row = row;
          if (this.candies[row + 1][col]) this.candies[row + 1][col].row = row + 1;
          
          // Check for matches
          const matches = this.findMatches();
          
          // Swap back
          [this.candies[row][col], this.candies[row + 1][col]] = 
          [this.candies[row + 1][col], this.candies[row][col]];
          
          // Update positions back
          if (this.candies[row][col]) this.candies[row][col].row = row;
          if (this.candies[row + 1][col]) this.candies[row + 1][col].row = row + 1;
          
          if (matches.length > 0) {
            return true;
          }
        }
      }
    }
    
    // No possible moves found
    return false;
  }
  
  /**
   * Reset the board for a new game
   */
  reset() {
    this.selectedCandy = null;
    this.isSwapping = false;
    this.isProcessingMatches = false;
    this.fillBoard();
    this.renderBoard();
  }
}