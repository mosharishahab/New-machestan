/**
 * Main entry point for the game
 */
document.addEventListener('DOMContentLoaded', () => {
  // Initialize the game
  Game.init();
  
  // Create assets directory with a placeholder for Taffy image
  createPlaceholderImages();
  
  // Support functions for the game
  function createPlaceholderImages() {
    // Create assets folder structure
    const assetsFolder = document.createElement('div');
    assetsFolder.style.display = 'none';
    document.body.appendChild(assetsFolder);
    
    // Set Taffy images to use a cat illustration from a stock image
    const taffyImg = document.getElementById('taffy-img');
    const taffyWelcomeImg = document.getElementById('taffy-welcome-img');
    
    // Use a Pexels stock image of a cat with a mustache look
    const catImageUrl = 'https://images.pexels.com/photos/45201/kitty-cat-kitten-pet-45201.jpeg';
    
    if (taffyImg) taffyImg.src = catImageUrl;
    if (taffyWelcomeImg) taffyWelcomeImg.src = catImageUrl;
  }
});