/**
 * Candy class to represent a candy piece on the board
 */
class Candy {
  /**
   * Create a new candy
   * @param {string} type - The type of candy (heart, circle, triangle, square)
   * @param {number} row - The row position on the board
   * @param {number} col - The column position on the board
   */
  constructor(type, row, col) {
    this.type = type;
    this.row = row;
    this.col = col;
    this.element = null;
    this.isMatched = false;
    this.isMoving = false;
    this.isSelected = false;
  }
  
  /**
   * Create the DOM element for this candy
   * @returns {HTMLElement} The candy DOM element
   */
  createElement() {
    const element = document.createElement('div');
    element.className = `candy ${this.type}`;
    element.dataset.row = this.row;
    element.dataset.col = this.col;
    
    this.element = element;
    return element;
  }
  
  /**
   * Update the DOM element position to match the candy's position
   */
  updatePosition() {
    if (this.element) {
      this.element.dataset.row = this.row;
      this.element.dataset.col = this.col;
    }
  }
  
  /**
   * Select this candy
   */
  select() {
    if (this.element && !this.isMatched) {
      this.isSelected = true;
      this.element.classList.add('selected');
    }
  }
  
  /**
   * Deselect this candy
   */
  deselect() {
    if (this.element) {
      this.isSelected = false;
      this.element.classList.remove('selected');
    }
  }
  
  /**
   * Mark this candy as matched
   */
  markAsMatched() {
    if (this.element) {
      this.isMatched = true;
      this.element.classList.add('match');
    }
  }
  
  /**
   * Set candy as moving (for animation)
   */
  setMoving(isMoving) {
    this.isMoving = isMoving;
    if (this.element) {
      if (isMoving) {
        this.element.classList.add('moving');
      } else {
        this.element.classList.remove('moving');
      }
    }
  }
  
  /**
   * Remove the candy from the DOM
   */
  remove() {
    if (this.element && this.element.parentNode) {
      this.element.parentNode.removeChild(this.element);
    }
  }
}