/**
 * Animations for the game
 */
const Animations = {
  /**
   * Animate a candy swap
   * @param {Candy} candy1 - First candy to swap
   * @param {Candy} candy2 - Second candy to swap
   * @returns {Promise} Promise that resolves when the animation is complete
   */
  async swapCandies(candy1, candy2) {
    // Mark candies as moving
    candy1.setMoving(true);
    candy2.setMoving(true);
    
    // Get positions
    const cell1 = document.querySelector(`.candy-cell[data-row="${candy1.row}"][data-col="${candy1.col}"]`);
    const cell2 = document.querySelector(`.candy-cell[data-row="${candy2.row}"][data-col="${candy2.col}"]`);
    
    if (!cell1 || !cell2) return;
    
    // Set initial and target positions
    const pos1 = cell1.getBoundingClientRect();
    const pos2 = cell2.getBoundingClientRect();
    
    // Calculate movement distances
    const deltaX1 = pos2.left - pos1.left;
    const deltaY1 = pos2.top - pos1.top;
    const deltaX2 = pos1.left - pos2.left;
    const deltaY2 = pos1.top - pos2.top;
    
    // Animate first candy
    candy1.element.style.zIndex = '10';
    candy1.element.style.transform = `translate(${deltaX1}px, ${deltaY1}px)`;
    
    // Animate second candy
    candy2.element.style.zIndex = '10';
    candy2.element.style.transform = `translate(${deltaX2}px, ${deltaY2}px)`;
    
    // Wait for animation to complete
    await Utils.delay(CONFIG.SWAP_ANIMATION_DURATION);
    
    // Reset transform and zIndex
    candy1.element.style.transform = '';
    candy2.element.style.transform = '';
    candy1.element.style.zIndex = '';
    candy2.element.style.zIndex = '';
    
    // Mark candies as not moving
    candy1.setMoving(false);
    candy2.setMoving(false);
  },
  
  /**
   * Animate matched candies popping
   * @param {Array} matchedCandies - Array of candies to pop
   * @returns {Promise} Promise that resolves when the animation is complete
   */
  async popCandies(matchedCandies) {
    // Mark candies as matched to start the pop animation
    matchedCandies.forEach(candy => {
      candy.markAsMatched();
    });
    
    // Wait for the pop animation to complete
    await Utils.delay(CONFIG.POP_ANIMATION_DURATION);
    
    // Remove the candy elements
    matchedCandies.forEach(candy => {
      candy.remove();
    });
  },
  
  /**
   * Animate candies dropping to fill gaps
   * @param {Array} droppingCandies - Array of candies that need to drop
   * @returns {Promise} Promise that resolves when the animation is complete
   */
  async dropCandies(droppingCandies) {
    // Set candies as moving
    droppingCandies.forEach(candy => {
      candy.setMoving(true);
      
      // Add drop animation
      if (candy.element) {
        candy.element.style.animation = `dropIn ${CONFIG.DROP_ANIMATION_DURATION / 1000}s ease-in-out forwards`;
      }
    });
    
    // Wait for the drop animation to complete
    await Utils.delay(CONFIG.DROP_ANIMATION_DURATION);
    
    // Clear animations and set candies as not moving
    droppingCandies.forEach(candy => {
      if (candy.element) {
        candy.element.style.animation = '';
      }
      candy.setMoving(false);
    });
  },
  
  /**
   * Show Taffy's speech bubble with text
   * @param {string} text - The text to display
   * @param {number} duration - How long to show the text in milliseconds
   */
  async showTaffySpeech(text, duration = 3000) {
    const speechBubble = document.getElementById('taffy-speech');
    const taffyText = document.getElementById('taffy-text');
    
    taffyText.textContent = text;
    speechBubble.classList.remove('hidden');
    
    if (duration > 0) {
      await Utils.delay(duration);
      speechBubble.classList.add('hidden');
    }
  },
  
  /**
   * Hide Taffy's speech bubble
   */
  hideTaffySpeech() {
    const speechBubble = document.getElementById('taffy-speech');
    speechBubble.classList.add('hidden');
  },
  
  /**
   * Update the objective progress bar
   * @param {number} current - Current progress
   * @param {number} target - Target value
   */
  updateProgressBar(current, target) {
    const progressFill = document.getElementById('progress-fill');
    const progressText = document.getElementById('progress-text');
    
    const percentage = Math.min(100, (current / target) * 100);
    progressFill.style.width = `${percentage}%`;
    progressText.textContent = `${current}/${target}`;
  }
};